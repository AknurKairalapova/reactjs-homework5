import React from 'react';

export default () => <p>Home page</p>;
