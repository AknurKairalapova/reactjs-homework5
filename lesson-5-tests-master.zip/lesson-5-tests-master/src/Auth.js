import React, {Component} from 'react';

class Auth extends Component {
  render() {
    return null;
  }
}

export default Auth;
